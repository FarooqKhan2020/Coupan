import React from 'react';
import { FaHeart, FaCheckCircle } from 'react-icons/fa';
import './CategoryCouponCard.css';

const CategoryCouponCard = ({ image, offer, verified, category, title, description, expiryDate, actionText }) => {
    return (
        <div className="coupon-card">
            <div className="coupon-card-image">
                <img src={image} alt={title} />
                <div className="coupon-card-heart">
                    <FaHeart />
                </div>
                <div className="coupon-card-offer">
                    {offer}
                </div>
            </div>
            <div className="coupon-card-tags">
                {verified && <span className="coupon-card-verified"><FaCheckCircle /> Verified</span>}
                <span className="coupon-card-category">{category}</span>
            </div>
            <div className="coupon-card-content">
                <h3>{title}</h3>
                <p>{description}</p>
            </div>
            <div className="coupon-card-footer">
                <span>Expire: {expiryDate}</span>
                <a href="#" className="coupon-card-action">{actionText}</a>
            </div>
        </div>
    );
};

export default CategoryCouponCard;
