import ContactUs from "../Components/ContactUs/ContactUs";
export default function ContactUsPage() {
  return (
    <>
      <ContactUs />
    </>
  );
}
