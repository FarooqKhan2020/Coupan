import CouponBar from "../Components/CategoryCoupon/CouponBar";
import CategoryCouponCard from "../Components/CategoryCoupon/CategoryCouponCard";
import couponImage from "../assets/carouseImg/foot.webp";

// Define your coupon data (can also be imported from another file)
const coupons = [
    {
        image: couponImage,
        offer: '-30% off',
        verified: true,
        category: 'Women',
        title: '60% Off Select Styles',
        description: 'Ei usu malis aeque efficiantur. Mazim dolor denique duo ad, augue ornatus senteniae vel at.',
        expiryDate: '10:23 AM, 26 Mar 2025',
        actionText: 'Get Code',
    },
    {
        image: couponImage,
        offer: '-20% off',
        verified: false,
        category: 'Men',
        title: '20% Off New Arrivals',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
        expiryDate: '12:00 PM, 30 Sep 2025',
        actionText: 'Buy Now',
    },
    
    // Add more coupons as needed
];

export default function CategoryCouponPage() {
  return (
    <>
      <CouponBar />
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', backgroundColor: 'var(--bg-main)' }}>
        {coupons.map((coupon, index) => (
          <CategoryCouponCard
            key={index}
            image={coupon.image}
            offer={coupon.offer}
            verified={coupon.verified}
            category={coupon.category}
            title={coupon.title}
            description={coupon.description}
            expiryDate={coupon.expiryDate}
            actionText={coupon.actionText}
          />
        ))}
      </div>
    </>
  );
}
